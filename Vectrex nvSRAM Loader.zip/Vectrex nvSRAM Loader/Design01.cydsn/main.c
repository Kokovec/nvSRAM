/* ===============================================================================================
 *
 * Vectrex nvSRAM Cart Loader
 * 
 * This is firmware that runs on the Vectrex nvSRAM Loader
 * This program will read a Vectrex ROM file through the serial port and program the nvSRAM Cart
 * It also has routines to dump the entire nvSRAM back through the serial port,
 * and test each of the nvSRAM Cart pins (the Cart must not have an nvSRAM chip soldered onto it).
 * Commands and data are received by the Loader via the serial port.
 * A sequencing diagram is provided in the Vectorbolt article (see Git readme)

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 * =================================================================================================
*/
#include "project.h"

void circuit_test();
void receive_data();
void send_data();
void SRAM_Write(uint16 addressbyte, uint8 databyte);
uint8 SRAM_Read(uint16 addressbyte);
void dump_SRAM();

// ****************************************************
// These arrays are used for the circuit test routine

// String tables
char const pin[26][8] = {"Pin_D0", "Pin_D1", "Pin_D2", "Pin_D3", "Pin_D4", "Pin_D5", "Pin_D6", "Pin_D7",
                          "Pin_A0", "Pin_A1", "Pin_A2", "Pin_A3", "Pin_A4", "Pin_A5", "Pin_A6", "Pin_A7",
                          "Pin_A8", "Pin_A9", "Pin_A10", "Pin_A11", "Pin_A12", "Pin_A13", "Pin_A14",
                          "Pin_A15", "Pin_WE", "Pin_OE"};

// Function pointers
static void (*test_write[26])(uint8) = {Control_Reg_Data_Write, Control_Reg_Data_Write, Control_Reg_Data_Write, Control_Reg_Data_Write,
                                        Control_Reg_Data_Write, Control_Reg_Data_Write, Control_Reg_Data_Write, Control_Reg_Data_Write,
                                        Control_Reg_Address_LSB_Write, Control_Reg_Address_LSB_Write, Control_Reg_Address_LSB_Write,
                                        Control_Reg_Address_LSB_Write, Control_Reg_Address_LSB_Write, Control_Reg_Address_LSB_Write,
                                        Control_Reg_Address_LSB_Write, Control_Reg_Address_LSB_Write, Control_Reg_Address_MSB_Write,
                                        Control_Reg_Address_MSB_Write, Control_Reg_Address_MSB_Write, Control_Reg_Address_MSB_Write,
                                        Control_Reg_Address_MSB_Write, Control_Reg_Address_MSB_Write, Control_Reg_Address_MSB_Write,
                                        Control_Reg_CE_Write, Control_Reg_WE_Write, Control_Reg_OE_Write};

// Bit patterns (for function _Write)
uint8 const bit_pattern[26] = {1, 2, 4, 8, 16, 32, 64, 128,
                               1, 2, 4, 8, 16, 32, 64, 128,
                               1, 2, 4, 8, 16, 32, 64,
                               1, 1, 1};
// ******************************************************

uint8 buffer[10], length;
uint8 x;                    // utility variable
uint8 y;                    // utility variable
uint16 z = 0;               // utility variable
uint16 file_length;         // length in bytes of file to be written to nvSRAM
uint8 Test = 0;             // variable used to get out of a while loop
uint16 address = 0;         // nvSRAM address (read / write)


int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    Clock_1_Start();                    // read register clock
    Clock_2_Start();                    // LED blink clock
    Control_Reg_LED_Write(1);           // LED blink selector: 0= blink, 1= off
    USBUART_Start(0u, USBUART_5V_OPERATION);
    while(!USBUART_GetConfiguration()); // Wait until USB is configured
    USBUART_EnableOutEP(3);             // Enable our output endpoint (EP3)

    for(;;)
    {
        // Wait for ping from PC
        Test = 0;
        while(Test == 0) 
        {
            receive_data();
            // Test for "A" sent from PC (program)
            if(buffer[0] == 'P') 
            {
                // send back ack
                buffer[0] = 'Z';
                send_data();
                Test = 1;               // break out of loop
            }
            // test for "R" sent from PC (read)
            else if(buffer[0] == 'R') 
            {
                buffer[0] = 'Z';
                send_data();
                dump_SRAM();
            }
            // test for "T" sent from PC (test)
            else if(buffer[0] == 'T')
            {   
                buffer[0] = 'Z';
                send_data();
                circuit_test();
            }
        }
        // First, get the file length from PC
        receive_data();
        x = buffer[0];
        receive_data();
        y = buffer[0];
        file_length = (uint16)x;
        file_length = file_length << 8;
        file_length = file_length | y;
        
        // echo it back to PC
        buffer[0] = file_length >> 8;
        send_data();
        buffer[0] = file_length;
        send_data();
        
        // Get ROM data and write to nvSRAM
        Control_Reg_LED_Write(0);           // start flashing the LED
        for(address=0;  address<file_length; address++)
        {
            receive_data();
            SRAM_Write(address, buffer[0]);
            buffer[0] = SRAM_Read(address);
            send_data();
        }
        buffer[0] = 0xFF;                   // signal back that we are done here
        send_data();
        Control_Reg_LED_Write(1);           // stop flashing the LED
    }
 
}


// ************************************************************************
// This function assists in performing a PCB circuit test of the nvSRAM loader board
// The Windows program must call it using: nvsram test, [COM]
// The Windows program sends text strings that describe the pin to test
// The text string looks like: Pin_D0, Pin_A1, Pin_OE....
// This function is not used for programming the nvSRAM board
// but is included for good measure
// DO NOT PLUG IN A POPULATED SRAM CART WHILE PERFORMING THIS TEST!!!!!!!
// ************************************************************************
void circuit_test() {
    char received_data[10];             // buffer for data received from PC
    uint8 end = 0;                      // function end test variable
    Control_Reg_LED_Write(0);           // start flashing the LED
    x = 0;                      
    // Set all pins low
    Control_Reg_Data_Write(0);      
    Control_Reg_Address_LSB_Write(0);
    Control_Reg_Address_MSB_Write(0);
    Control_Reg_WE_Write(0);
    Control_Reg_CE_Write(0);
    Control_Reg_OE_Write(0);
       
    while(end == 0)
    {
        buffer[0] = 1;
        x = 0;
        // receive data from USB port, keep going until terminator character is received
        while(buffer[0] != 0)
        {
            receive_data();
            received_data[x] = buffer[0];
            send_data();
            x = x + 1;
        }
        // check if we need to exit function
        if(strcmp(received_data, "T") == 0)
        {
            end= 1;
        }
        // check to see which pin to set high
        for(y=0; y<26; y++)
        {
            if(strcmp(received_data, &pin[y][0]) == 0)
            {
                Control_Reg_Data_Write(0);
                Control_Reg_Address_LSB_Write(0);
                Control_Reg_Address_MSB_Write(0);
                Control_Reg_WE_Write(0);
                Control_Reg_CE_Write(0);
                test_write[y](bit_pattern[y]);
            }
        }
    }
    // stop LED from blinking before exit
    Control_Reg_LED_Write(1);
}

void receive_data()
{
    while(USBUART_GetEPState(3) == USBUART_OUT_BUFFER_EMPTY); // Wait until we have data
    length = USBUART_GetEPCount(3); // Get the length of received data
    USBUART_ReadOutEP(3, buffer, 1); // Get the data
}

void send_data()
{
    while(USBUART_GetEPState(2) != USBUART_IN_BUFFER_EMPTY); // Wait until our INEP is empty
    USBUART_LoadInEP(2, buffer, 1); // Echo the data back into the buffer
}

void SRAM_Write(uint16 addressbyte, uint8 databyte)
{
    uint8 a = 0;
    // set up SRAM control pins
    Control_Reg_WE_Write(0);        // 0 = write to SRAM
    Control_Reg_OE_Write(1);        // 1 = data lines are inputs
    // send address to SRAM
    a = addressbyte >> 8;
    Control_Reg_Address_MSB_Write(a);
    Control_Reg_Address_LSB_Write((uint8) addressbyte);
    // send data to SRAM
    Control_Reg_Data_Write(databyte);
    // enable write to SRAM
    Control_Reg_CE_Write(0);
    //CyDelayUs(1);
    // stop wrtie to SRAM
    Control_Reg_CE_Write(1);
    // tri-state PSOC data pins
    Control_Reg_WE_Write(1);        // data line are now tri-state
}

uint8 SRAM_Read(uint16 addressbyte)
{
    uint8 a = 0;
    uint8 b = 0;
    // set up SRAM control pins
    Control_Reg_WE_Write(1);        // 1 = read from SRAM
    Control_Reg_OE_Write(0);        // 1 = data line are outputs
    // send address to SRAM
    a = addressbyte >> 8;
    Control_Reg_Address_MSB_Write(a);
    Control_Reg_Address_LSB_Write((uint8) addressbyte);
    // enable write to SRAM
    Control_Reg_CE_Write(0);
    //CyDelayUs(1);
    // read data from SRAM
    b = Status_Reg_Data_Read();
    // stop write to SRAM
    Control_Reg_CE_Write(1);
     // tri-state PSOC data pins
    Control_Reg_WE_Write(1); 
    Control_Reg_OE_Write(1);        // 1 = data line are inputs
    return b;
}

void dump_SRAM()
{
    uint16 myaddress;
    // First, get the file length from PC
    receive_data();
    x = buffer[0];
    receive_data();
    y = buffer[0];
    file_length = (uint16)x;
    file_length = file_length << 8;
    file_length = file_length | y;
    
    // echo it back to PC
    buffer[0] = file_length >> 8;
    send_data();
    buffer[0] = file_length;
    send_data();
        
    // send out all of the requested bytes
    for(myaddress=0; myaddress<file_length; myaddress++)
    {
        buffer[0] = SRAM_Read(myaddress);
        send_data();
    }
}
/* [] END OF FILE */
